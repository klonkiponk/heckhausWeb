<?php		
	header('Location:../de/index.php');
?>
