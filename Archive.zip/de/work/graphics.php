<article>
	<?php include("../../admin/data/blocks/de/work_graphics.html"); ?>	
</article>