<article>
	<?php include("../../admin/data/blocks/de/work_home.html"); ?>	
</article>