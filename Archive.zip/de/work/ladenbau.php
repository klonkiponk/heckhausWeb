<article>
	<?php include("../../admin/data/blocks/de/work_ladenbau.html"); ?>	
</article>