<article>
	<?php include("../../admin/data/blocks/de/work_bestof.html"); ?>	
</article>