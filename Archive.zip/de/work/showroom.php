<article>
	<?php include("../../admin/data/blocks/de/work_showroom.html"); ?>	
</article>