<article>
	<?php include("../../admin/data/blocks/de/work_setdesign.html"); ?>	
</article>