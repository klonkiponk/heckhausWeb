<article>
	<?php include("../../admin/data/blocks/de/work_retail.html"); ?>	
</article>