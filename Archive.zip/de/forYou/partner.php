<article>
	<?php include("../../admin/data/blocks/de/foryou_partner.html"); ?>	
</article>