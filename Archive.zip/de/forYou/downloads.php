<article>
<?php include("../../admin/data/blocks/de/foryou_downloads.html"); ?>	
</article>