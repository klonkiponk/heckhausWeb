<?php include("../etc/config.php");?>
<?php $lang = $_GET['lang']; ?>
<?php include("../php/inc.head.php");?>
<body>
<?php include("../php/inc.header.subSites.php");?>
<div id="wrapper">	
<div class="container">

<article>
	<?php include("../admin/data/blocks/de/Agb.html"); ?>	
</article>
	<?php include("../php/inc.footer.php") ;?>
</div>
</div>
<?php include("../php/inc.scripts.php");?>
<script type="text/javascript" src="../js/heckhaus.subSite.js"></script>
</body>
</html>