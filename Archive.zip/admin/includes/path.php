<?php 
define('ROOTPATH', dirname(dirname(__FILE__))); 
?>