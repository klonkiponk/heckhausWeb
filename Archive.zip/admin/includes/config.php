<?php
$pulse_pass = "Bohne85%86";
$pulse_dir = "admin";
$height = "";
$width = "";
$blog_url = "http://example.com/blog.php";
$per_page = "5";
$blog_title = "My Blog Name";
$rewrite = false;
$blog_description = "";
$blog_comments = true;
$blog_capcha = true;
$questions["What color is the ocean?"] = "blue";
$questions["What is the year after this one?"] = "2014";
$questions["How many letters in the word MARKET?"] = "6";
$date_format = "0";
$email_contact = "kevin@siegerth.com";
$pulse_lang = "0";
$custom_fieldname1 = "";
$custom_fieldname2 = "";
$formcap = "1";
?>