<!DOCTYPE html>
<html>
<head>
	<title>HECKHAUS</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<link href="<?php echo SERVER ?>/css/style.css" rel="stylesheet" media="screen">
	<meta charset="utf-8">
	<link type="image/icon" href="<?php echo SERVER ?>/img/heckhaus_favicon.ico" rel="shortcut icon" />	
</head>