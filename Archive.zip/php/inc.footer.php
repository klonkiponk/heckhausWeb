<div class="divider"></div>
<div class="divider"></div>
<footer class="container">
		<div class="col-md-9 footerLeft">
			Heckhaus ist eine Design- und Planungsagentur für Ladenbau, Showrooms, Shop-in-Shop-Systeme, Displays, Messestände und Set-Design. Unser Anspruch: Individualität.
			<hr>
			<p><a href="https://www.facebook.com/pages/Heckhaus/109524019089498?ref=ts"><button class="btn btn-danger">LIKE</button></a> us on Facebook</p>
			+ SUBSCRIBE TO NEWSLETTER
			<hr>
			Copyright © <?php echo date("Y");?> Heckhaus | <a href="/<?php echo $lang;?>/impressum.php">Impressum</a> | <a href="/<?php echo $lang;?>/agb.php">AGB</a>
	Referenzen: Ladenbau | Shop-in-Shop | Displays & Aufsteller | Graphics & Visuals | Messedesign & Messeplanung | Set Design | Showroom Design | Schaufenster-Inszenierung
		</div>
		<div class="col-md-3 footerRight">
			<address>
				<h3>HECKHAUS</h3>
				GmbH & Co. KG<br>
				<br>
				Thalkirchner Strasse 62<br>
				80337 München<br>
				Fon +49 (0)89 - 62 27 17 - 30<br>
				Fax +49 (0)89 - 62 27 17 - 39<br>
				<a href="mailto:info@heckhaus.de">info [ at ] heckhaus.de</a>
			</address>
		</div>
</footer>