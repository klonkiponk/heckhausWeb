<script type="text/javascript" src="<?php echo SERVER ?>/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="<?php echo SERVER ?>/js/lightbox-2.6.min.js"></script>